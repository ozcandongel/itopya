<?php

namespace InstagramAPI\Exception;

class InvalidSmsCodeException extends RequestException
{
}
