<?php

namespace GetOptionKit\ValueType;

/**
 * An alias class for boolean type.
 */
class BoolType extends BooleanType
{
}
